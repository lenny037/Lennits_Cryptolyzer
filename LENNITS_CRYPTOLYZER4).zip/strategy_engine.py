def signal(): return 'BUY'
