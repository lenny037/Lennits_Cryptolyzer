@ECHO OFF
gradlew %*
