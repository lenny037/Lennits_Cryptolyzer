def risk(): return 'OK'
